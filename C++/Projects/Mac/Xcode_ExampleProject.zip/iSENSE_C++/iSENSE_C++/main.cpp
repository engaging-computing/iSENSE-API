//
//  main.cpp
//  iSENSE_C++
//
//  Created by Jason on 1/16/15.
//  Copyright (c) 2015 ECG. All rights reserved.
//

#include <iostream>

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
